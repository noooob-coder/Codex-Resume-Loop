# CRL

CRL 是一个用 Rust + Slint 构建的桌面工具，用来同时管理多个项目工作区里的 Codex 会话，批量执行 `resume` 轮次，并在桌面端直接查看实时输出。

它提供两种入口：

- `crl-desktop`：图形界面，适合盯任务、切工作区、看输出
- `crl`：命令行，适合当前目录下直接恢复最新或指定会话

## 先决条件

- 已安装并可执行 `codex`
- 本机可访问 `~/.codex`
- Windows 建议安装 WebView2 Runtime

## 快速开始

桌面端：

```powershell
cargo run --bin crl-desktop
```

CLI：

```powershell
cargo run --bin crl -- --help
```

开发检查：

```powershell
cargo test
cargo clippy --all-targets --all-features -- -D warnings
```

## 发布产物

- Windows 安装包：`dist\crl-setup-windows-x64.exe`，内含桌面端和 CLI
- Linux CLI：`dist\crl-cli-linux-x86_64.tar.gz`
- iOS：在 macOS + Xcode 环境运行 `packaging/ios/build-ui-and-cli.sh`

## 桌面端怎么用

1. 在顶部设置 `Codex` 目录。
2. 添加一个或多个项目目录。
3. 在左侧切换工作区。
4. 在中间栏选择目标会话、设置轮次和提示词。
5. 点击“启动任务”。
6. 在右侧查看实时输出，支持选择和复制。

界面说明：

- 左栏：工作区列表和切换入口
- 中栏：当前工作区的任务控制、目标会话、提示词、运行反馈
- 右栏：命令输出流

## CLI 怎么用

列出当前目录可恢复的会话：

```powershell
crl --list-sessions
```

直接执行指定轮次：

```powershell
crl 3 "继续上一次结束的位置，完成未完成的工作。"
```

只看计划，不真正执行：

```powershell
crl --dry-run 3 "继续上一次结束的位置，完成未完成的工作。"
```

## 项目结构

- `src/desktop.rs`：桌面端控制器、状态同步、任务调度入口
- `src/codex.rs`：Codex 启动、会话发现、恢复提示词构造
- `src/runtime.rs`：后台运行时与输出流转发
- `src/model.rs`：应用状态、工作区状态、日志模型
- `src/persistence.rs`：本地状态持久化
- `src/bin/crl.rs`：CLI 入口
- `ui/main.slint`：桌面 UI

## 当前实现重点

- 多工作区统一调度
- 桌面端和 CLI 复用同一套 Codex 恢复命令构造
- 会话刷新按 Codex 目录建立索引后复用，避免多工作区重复全量扫描
- 某一轮失败时仍会尝试剩余轮次，最后统一汇总失败轮次
- 输出区和中间栏以纵向阅读为主，长文本自动换行

## 用 git 管理

推荐在每次改动后至少执行：

```powershell
git status
git add -A
git commit -m "describe the change"
```

查看最近提交：

```powershell
git log --oneline --decorate -n 10
```
